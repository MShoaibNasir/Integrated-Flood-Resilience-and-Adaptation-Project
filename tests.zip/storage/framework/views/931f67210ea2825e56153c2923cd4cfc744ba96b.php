<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>DASHMIN - Bootstrap Admin Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">
    <!-- Favicon -->
    <style>
        a.nav-link.dropdown-toggle {
            font-size: 14px;
        }

        .sidebar {
            width: 298px !important;
        }

        .form_width {
            padding-left: 3.5rem !important;
        }

        
    </style>
    <?php echo $__env->make('dashboard.layout.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <div class="container-xxl position-relative bg-white d-flex p-0">
        <!-- Sidebar Start -->
        <?php if(Auth::user()->role == 1): ?>
            <?php echo $__env->make('dashboard.layout.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php elseif(Auth::user()->role == 2): ?>   
            <?php echo $__env->make('dashboard.layout.admin_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php endif; ?>
        <!-- Sidebar End --><?php /**PATH C:\xampp\htdocs\unknown\IFRAP\resources\views/dashboard/layout/header.blade.php ENDPATH**/ ?>