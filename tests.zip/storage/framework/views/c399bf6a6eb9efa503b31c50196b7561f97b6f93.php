<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo e(asset('dashboard/lib/chart/chart.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/lib/easing/easing.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/lib/waypoints/waypoints.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/lib/tempusdominus/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/lib/tempusdominus/js/moment-timezone.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js')); ?>"></script>
    <script scr="https://code.jquery.com/jquery-3.7.1.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo e(asset('dashboard/js/main.js')); ?>"></script>
    <script src="//cdn.datatables.net/2.1.3/js/dataTables.min.js"></script><?php /**PATH C:\xampp\htdocs\unknown\IFRAP\resources\views/dashboard/layout/js.blade.php ENDPATH**/ ?>