<?php echo $__env->make('dashboard.layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdn.datatables.net/2.1.3/css/dataTables.dataTables.min.css">
<style>
      .form_width {
            padding-left: 3.5rem !important;
        }
</style>
<?php echo $__env->yieldContent('content'); ?>
<script src="https://code.jquery.com/jquery-3.7.1.js"></script>
<script src="https://cdn.datatables.net/2.1.3/js/dataTables.min.js"></script>
<script>
        let table = new DataTable('#myTable');
    </script>
<?php echo $__env->make('dashboard.layout.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\unknown\IFRAP\resources\views/dashboard/layout/master.blade.php ENDPATH**/ ?>